package com.minggu5.restaurant;
import java.util.logging.Logger;

/*
*@author Xaviera
*Program to order food from restaurant
*@version 2.0
*@since 2023-09-25
*/

public class RestaurantModules {
    private static final Logger logger = Logger.getLogger(RestaurantModules.class.getName());

    private String[] namaMakanan;
    private double[] hargaMakanan;
    private int[] stok;
    static byte id = 0;

    public RestaurantModules() {
        namaMakanan = new String[10];
        hargaMakanan = new double[10];
        stok = new int[10];
    }

    // Add public accessor methods (getters) for the private fields
    public String[] getNamaMakanan() {
        return namaMakanan;
    }

    public double[] getHargaMakanan() {
        return hargaMakanan;
    }

    public int[] getStok() {
        return stok;
    }

    public void tambahMenuMakanan(String nama, double harga, int stok) {
        this.namaMakanan[id] = nama;
        this.hargaMakanan[id] = harga;
        this.stok[id] = stok;
    }


    public void tampilMenuMakanan() {
        logger.info("Daftar Menu:");
        logger.info("----------------------------------------------");
        logger.info("| No | Nama Menu        | Stok |    Harga    |");
        logger.info("----------------------------------------------");
        for (int i = 0; i <= id; i++) {
            if (!isOutOfStock(i)) {
                String noMenu = String.format("| %2d |", i + 1);
                String namaMenu = String.format(" %-16s |", namaMakanan[i]);
                String stokMenu = String.format(" %3d |", stok[i]);
                String hargaMenu = String.format(" Rp. %,.2f |", hargaMakanan[i]);
                String menuString = noMenu + namaMenu + stokMenu + hargaMenu;
                logger.info(menuString);
            }
        }
        logger.info("---------------------------------------------");
    }

    public boolean isOutOfStock(int id) {
        return stok[id] == 0;
    }

    public static void nextId() {
        id++;
    }
}

class Produk {
    public String nama_produk;
    public double harga;
    public int qty;

    public Produk(String nama_produk, double harga, int qty) {
        this.nama_produk = nama_produk;
        this.harga = harga;
        this.qty = qty;
    }
}

class Penjualan {
    public Produk produk;
    public int quantity;
    public double harga_total;

    public Penjualan(Produk produk, int quantity) {
        this.produk = produk;
        this.quantity = quantity;
        this.harga_total = produk.harga * quantity;
    }
}

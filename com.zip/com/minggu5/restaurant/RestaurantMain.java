package com.minggu5.restaurant;

import java.util.Scanner;
import java.util.logging.Logger;

public class RestaurantMain {
    private static final Logger logger = Logger.getLogger(RestaurantMain.class.getName());

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        RestaurantModules menu = new RestaurantModules();

        menu.tambahMenuMakanan("Bala-Bala", 1_500, 50);
        RestaurantModules.nextId();
        menu.tambahMenuMakanan("Gehu", 1_500, 45);
        RestaurantModules.nextId();
        menu.tambahMenuMakanan("Tahu Walik", 2_000, 40);
        RestaurantModules.nextId();
        menu.tambahMenuMakanan("Molen", 2_000, 20);
        RestaurantModules.nextId();
        menu.tambahMenuMakanan("Risol Bihun", 1_500, 50);
        RestaurantModules.nextId();
        menu.tambahMenuMakanan("Risol Mayo", 3_500, 60);
        RestaurantModules.nextId();
        menu.tambahMenuMakanan("Cireng", 1_500, 9);
        RestaurantModules.nextId();
        menu.tambahMenuMakanan("Pastel", 2_500, 23);
        RestaurantModules.nextId();
        menu.tambahMenuMakanan("Lontong", 5_000, 18);
        RestaurantModules.nextId();
        menu.tambahMenuMakanan("Teh Tawar Hangat", 7_000, 11);


        boolean pesanLain = true;
        double totalBayar = 0;

        Produk produk = null;
        String namaProdukDipesan = null;

        while (pesanLain) {
            menu.tampilMenuMakanan();
            logger.info("Pilih indeks menu (0 untuk keluar dan membayar): ");
            int pilihan = scanner.nextInt();

            if (pilihan == 0) {
                pesanLain = false;
                logger.info("Terima kasih telah menggunakan layanan kami.");
                continue;
            }

            if (pilihan >= 1 && pilihan <= RestaurantModules.id) {
                int index = pilihan - 1;
                int stokTersedia = menu.getStok()[index]; // Access stok array using the getter

                if (stokTersedia > 0) {
                	logger.info("Jumlah yang dipesan (max " + stokTersedia + "): ");
                    int qty = scanner.nextInt();

                    if (qty <= stokTersedia) {
                        produk = new Produk(menu.getNamaMakanan()[index], menu.getHargaMakanan()[index], qty); // Access namaMakanan and hargaMakanan arrays using getters
                        Penjualan pesanan = new Penjualan(produk, qty);

                        namaProdukDipesan = produk.nama_produk;

                        logger.info("Pesanan: " + namaProdukDipesan + " x" + pesanan.quantity + " = Rp. " + pesanan.harga_total);
                        totalBayar += pesanan.harga_total;

                        menu.getStok()[index] -= qty; // Access stok array using the getter

                        menu.tampilMenuMakanan();
                    } else {
                        logger.info("Maaf, jumlah yang diminta melebihi stok. Hanya " + stokTersedia + " " + menu.getNamaMakanan()[index] + " yang dapat dipesan.");
                        logger.info("Pesanan: " + menu.getNamaMakanan()[index] + " x" + stokTersedia + " = Rp. " + (menu.getHargaMakanan()[index] * stokTersedia));
                        totalBayar += menu.getHargaMakanan()[index] * stokTersedia;
                        menu.getStok()[index] = 0;

                        menu.tampilMenuMakanan();
                    }
                } else {
                    logger.info("Maaf, stok " + menu.getNamaMakanan()[index] + " telah habis.");
                }
            } else {
                logger.info("Menu tidak valid.");
            }
        }

        logger.info("Total bayar: Rp. " + totalBayar);
        scanner.close();
    }
}

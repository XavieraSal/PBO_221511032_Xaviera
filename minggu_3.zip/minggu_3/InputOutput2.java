package minggu_3;

import java.util.Scanner;

/*
*@author Xaviera
*Program to print formatted output
*@version 1.0
*@since 2023-09-10
*/

public class InputOutput2 {
    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        int jmlh = 0;
        String inpstr;
        int inpInt;
        System.out.print("Masukkan 3 String: ");
        while (jmlh < 3 && keyboard.hasNext()) {
            inpstr = keyboard.next();
            inpInt = keyboard.nextInt();
            System.out.printf("%-15s%03d%n", inpstr, inpInt);

            jmlh++;
        }

        keyboard.close();
    }
}

package minggu_3;

import java.util.Scanner;

/*
*@author Xaviera
*Program to split the string into tokens
*@version 1.0
*@since 2023-09-07
*/

public class InputOutput1 {

	public static void main(String[] args) {
		
		String inp;
		String[] outp;
		Scanner keyboard = new Scanner(System.in); //Objek Scanner untuk mengambil input dari pengguna.
		
		System.out.print("Masukkan String: ");
		inp = keyboard.nextLine();
		outp = inp.split("[^A-Za-z]+");
		System.out.println(outp.length);
		
		for (String token : outp) {
	        if (!token.isEmpty()) {
	            System.out.println(token);
	            }
	        }
		    keyboard.close();
		    }
		}

	
		


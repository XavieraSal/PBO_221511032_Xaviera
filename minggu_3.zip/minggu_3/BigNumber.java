package minggu_3;

/*
*@author Xaviera
*Program to use big Number
*@since 2023-09-10
*/

import java.util.Scanner;
import java.math.BigInteger;

public class BigNumber {
    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        System.out.print("Masukkan angka 1: ");
        String num1 = keyboard.nextLine();
        System.out.print("Masukkan angka 2: ");
        String num2 = keyboard.nextLine();

        //buat Big Integer dari inputan
        BigInteger a = new BigInteger(num1);
        BigInteger b = new BigInteger(num2);

        BigInteger sum = a.add(b);
        BigInteger product = a.multiply(b);

        System.out.println(sum.toString().replaceAll("^0+", ""));
        System.out.println(product.toString().replaceAll("^0+", ""));

        keyboard.close();
    }
}

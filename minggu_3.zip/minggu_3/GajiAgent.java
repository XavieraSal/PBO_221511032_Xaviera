package minggu_3;

/*
*@author Xaviera
*Program to compute agent's salary from bonus
*@version 1.0
*@since 2023-09-10
*/

import java.util.Scanner;

public class GajiAgent {
    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);

        //Membaca jumlah penjualan bulan ini
        System.out.print("Item yang berhasil dijual: ");
        int jumlahPenjualan = keyboard.nextInt();

        //Gaji pokok agent
        int gajiPokok = 500000;

        //Harga setiap item
        int hargaPerItem = 50000;

        //Menghitung bonus penjualan
        double bonusPenjualan = 0.0;

        if (jumlahPenjualan >= 40) {
            if (jumlahPenjualan > 80) {
            	bonusPenjualan = (0.25 * hargaPerItem * (jumlahPenjualan - 40)) + (0.35 * hargaPerItem * (jumlahPenjualan - 80));
            } else {
                bonusPenjualan = (0.25 * hargaPerItem * (jumlahPenjualan - 40));
            }
        } else if (jumlahPenjualan < 15) {
            bonusPenjualan = -0.15 * hargaPerItem * (15 - jumlahPenjualan);
        }

        //Menghitung total gaji
        int totalGaji = (int) (gajiPokok + bonusPenjualan);

        //Menampilkan total gaji
        System.out.println("Total Gaji Agent: " + totalGaji);

        keyboard.close();
    }
}

package minggu_3;

/*
*@author Xaviera
*Program to use basic math operator
*@version 1.0
*@since 2023-09-10
*/

import java.util.Scanner;

public class Berhitung {
    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        int A, B, hasil;
        //Membaca input
        System.out.print("Masukkan operasi: ");
        A = keyboard.nextInt();
        String operator = keyboard.next(); //Baca operator ke dalam variabel
        B = keyboard.nextInt();
        

        hasil = 0;
        if (operator.equals("+")) {
            hasil = A + B;
        } else if (operator.equals("-")) {
            hasil = A - B;
        } else if (operator.equals("*")) {
            hasil = A * B;
        } else if (operator.equals("/")) {
            hasil = A / B;
        } else if (operator.equals("%")) {
            hasil = A % B;
        }

        System.out.println(hasil);

        keyboard.close();
    }
}

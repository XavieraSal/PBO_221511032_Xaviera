package minggu_3;

/*
*@author Xaviera
*Program to know what roud should be opened or not
*@version 1.0
*@since 2023-09-10
*/

import java.util.Scanner;

public class BukaTutupJalan {
    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);

        //Membaca plat nomor 4 mobil
        System.out.print("Masukkan plat nomor 4 mobil: ");
        int[] platNomor = new int[4];
        for (int i = 0; i < 4; i++) {
            platNomor[i] = keyboard.nextInt();
        }

        //Menggabungkan plat nomor 4 mobil
        int gabungan = 0;
        for (int i = 0; i < 4; i++) {
            gabungan += platNomor[i];
        }

        //Memeriksa apakah harus berhenti atau melanjutkan
        if ((gabungan - 999999) % 5 == 0) {
            System.out.println("Berhenti");
        } else {
            System.out.println("Jalan");
        }

        keyboard.close();
    }
}

package minggu_4_PBO_PR;

public class Restaurant {
	public String[] nama_makanan;
	public double[] harga_makanan;
	public int[] stok;
	public static byte id=0;
	
	public Restaurant() {
		nama_makanan = new String[10];
		harga_makanan = new double[10];
		stok =new int[10];
	}
	
	public void tambahMenuMakanan (String nama, double harga, int stok) {
		this.nama_makanan[id] = nama;
		this.harga_makanan[id] = harga;
		this.stok[id] = stok;
	}
	
	
	public void tampilMenuMakanan() {
	    System.out.println("Daftar Menu:");
	    System.out.println("----------------------------------------------");
	    System.out.println("| No | Nama Menu        | Stok |    Harga    |");
	    System.out.println("----------------------------------------------");
	    for (int i = 0; i <= id; i++) {
	        if (!isOutOfStock(i)) {
	            String noMenu = String.format("| %2d |", i + 1);
	            String namaMenu = String.format(" %-16s |", nama_makanan[i]);
	            String stokMenu = String.format(" %3d |", stok[i]);
	            String hargaMenu = String.format(" Rp. %,.2f |", harga_makanan[i]);
	            String menuString = noMenu + namaMenu + stokMenu + hargaMenu;
	            System.out.println(menuString);
	        }
	    }
	    System.out.println("---------------------------------------------");
	}

	
	public boolean isOutOfStock(int id) {
		if(stok[id] == 0) {
			return true;
		}else {
			return false;
		}
	}
	
public static void nextId(){
		id++;
	}

}

class Produk {
    public String nama_produk;
    public double harga;
    public int qty;

    public Produk(String nama_produk, double harga, int qty) {
        this.nama_produk = nama_produk;
        this.harga = harga;
        this.qty = qty;
    }
}

class Penjualan {
    public Produk produk;
    public int quantity;
    public double harga_total;

    public Penjualan(Produk produk, int quantity) {
        this.produk = produk;
        this.quantity = quantity;
        this.harga_total = produk.harga * quantity;
    }
}
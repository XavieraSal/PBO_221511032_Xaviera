package minggu_4_PBO_PR;

import java.util.Scanner;

public class RestaurantMain {
	public static void main(String [] args) {
        Scanner scanner = new Scanner(System.in);
        Restaurant menu = new Restaurant();

        menu.tambahMenuMakanan("Bala-Bala", 1_500, 50);
        Restaurant.nextId();
        menu.tambahMenuMakanan("Gehu", 1_500, 45);
        Restaurant.nextId();
        menu.tambahMenuMakanan("Tahu Walik", 2_000, 40);
        Restaurant.nextId();
        menu.tambahMenuMakanan("Molen", 2_000, 20);
        Restaurant.nextId();
        menu.tambahMenuMakanan("Risol Bihun", 1_500, 50);
        Restaurant.nextId();
        menu.tambahMenuMakanan("Risol Mayo", 3_500, 60);
        Restaurant.nextId();
        menu.tambahMenuMakanan("Cireng", 1_500, 9);
        Restaurant.nextId();
        menu.tambahMenuMakanan("Pastel", 2_500, 23);
        Restaurant.nextId();
        menu.tambahMenuMakanan("Lontong", 5_000, 18);
        Restaurant.nextId();
        menu.tambahMenuMakanan("Teh Tawar Hangat", 7_000, 11);
        
        
        boolean pesanLain = true;
        double totalBayar = 0;
        
        Produk produk = null;
        String namaProdukDipesan = null; // Tambahkan variabel untuk nama produk yang dipesan

        while (pesanLain) {
            menu.tampilMenuMakanan();
            System.out.print("Pilih menu (0 untuk membayar) ");
            System.out.print("Jika tidak, pilih nomor makanan lain: ");
            int pilihan = scanner.nextInt();
            if (pilihan == 0) {
                pesanLain = false;
                continue;
            }
            if (pilihan >= 1 && pilihan <= Restaurant.id) {
                int index = pilihan - 1; // Mengubah pilihan menjadi indeks array
                int stokTersedia = menu.stok[index]; // Menyimpan stok yang tersedia
                if (stokTersedia > 0) {
                    System.out.print("Jumlah yang dipesan (max " + stokTersedia + "): ");
                    int qty = scanner.nextInt();
                    if (qty <= stokTersedia) {
                        produk = new Produk(menu.nama_makanan[index], menu.harga_makanan[index], qty);
                        Penjualan pesanan = new Penjualan(produk, qty);
                        
                        // Simpan nama produk yang dipesan
                        namaProdukDipesan = produk.nama_produk;
                        
                        System.out.println("Pesanan: " + namaProdukDipesan + " x" + pesanan.quantity + " = Rp. " + pesanan.harga_total);
                        totalBayar += pesanan.harga_total;

                        // Mengurangi stok yang tersedia
                        menu.stok[index] -= qty;

                        // Cetak ulang daftar menu setelah pesanan
                        menu.tampilMenuMakanan();
                    } else {
                        // Jika pesanan melebihi stok, pesanan dibatasi oleh stok yang tersedia
                        System.out.println("Maaf, jumlah yang diminta melebihi stok. Hanya " + stokTersedia + " " + menu.nama_makanan[index] + " yang dapat dipesan.");
                        System.out.println("Pesanan: " + menu.nama_makanan[index] + " x" + stokTersedia + " = Rp. " + (menu.harga_makanan[index] * stokTersedia));
                        totalBayar += menu.harga_makanan[index] * stokTersedia;
                        menu.stok[index] = 0; // Mengubah stok menjadi 0
                        menu.tampilMenuMakanan();
                    }
                } else {
                    System.out.println("Maaf, stok " + menu.nama_makanan[index] + " telah habis.");
                }
            } else {
                System.out.println("Menu tidak valid.");
            }
        }

        System.out.println("Total bayar: Rp. " + totalBayar);
        scanner.close();
	}
}

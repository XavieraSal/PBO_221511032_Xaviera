package java_collection_exercise_te;

import java.util.*;

public class Family {
    private Set<Niece> nieces;
    private Set<Uncle> uncles;

    public Family() {
        this.nieces = new HashSet<Niece>();
        this.uncles = new HashSet<Uncle>();
    }

    public boolean addNiece(String name, int day, int month) {
        // Create a new Niece object and set its attributes
        Niece temp = new Niece();
        temp.setName(name);
        temp.setBirthDay(day);
        temp.setBirthMonth(month);

        // Add the niece to the set and update the present list
        if (nieces.add(temp)) {
            this.updatePresentList();
            return true;
        }
        return false;
    }

    public boolean addUncle(String name) {
        // Create a new Uncle object and set its name
        Uncle temp = new Uncle();
        temp.setName(name);

        // Add the uncle to the set and update the present list
        if (uncles.add(temp)) {
            this.updatePresentList();
            return true;
        }
        return false;
    }

    public Niece findNiece(String name) {
        // Iterate over nieces to find the one with the specified name
        for (Iterator<Niece> it = nieces.iterator(); it.hasNext(); ) {
            Niece temp = it.next();
            if (temp.getName().equals(name)) {
                return temp;
            }
        }
        return null;
    }

    public Uncle findUncle(String name) {
        // Iterate over uncles to find the one with the specified name
        for (Iterator<Uncle> it = uncles.iterator(); it.hasNext(); ) {
            Uncle temp = it.next();
            if (temp.getName().equals(name)) {
                return temp;
            }
        }
        return null;
    }

    public void listOfNieces() {
        // Use TreeSet to automatically sort nieces and print the sorted list
        TreeSet<Niece> sortedNieces = new TreeSet<Niece>(nieces);
        System.out.println(sortedNieces);
    }

    public void listOfUncles() {
        // Use TreeSet to automatically sort uncles and print the sorted list
        TreeSet<Uncle> sortedUncles = new TreeSet<Uncle>(uncles);
        System.out.println(sortedUncles);
    }

    private void updatePresentList() {
        // Update the present list for each uncle and niece combination
        for (Uncle uncle : uncles) {
            for (Niece niece : nieces) {
                if (!uncle.getPresents().containsKey(niece)) {
                    uncle.addPresent(niece, null);
                }
            }
        }
    }
}

package java_collection_exercise_te;

public class Main {
    // Define constants for niece's names
    private static final String NIECE_NINA = "Nina";
    private static final String NIECE_DIETER = "Dieter";
    private static final String NIECE_JOHAN = "Johan";

    public static void main(String[] args) {
        // Create a Family object to manage the family structure
        Family family = new Family();

        // Add Nieces using constants
        family.addNiece(NIECE_NINA, 8, 5);
        family.addNiece(NIECE_DIETER, 10, 9);
        family.addNiece(NIECE_JOHAN, 7, 4);

        // Add Uncles using constants
        family.addUncle("Tenma");
        family.addUncle("Grimmer");
        family.addUncle("Lunge");

        // Find Uncles using constants
        Uncle uncle1 = family.findUncle("Tenma");
        Uncle uncle2 = family.findUncle("Grimmer");
        Uncle uncle3 = family.findUncle("Lunge");

        // Add Presents using constants
        uncle1.addPresent(family.findNiece(NIECE_NINA), "Knitted Gloves");
        uncle1.addPresent(family.findNiece(NIECE_DIETER), "Knitted Socks");
        uncle1.addPresent(family.findNiece(NIECE_JOHAN), "Knitted Sweater");

        uncle2.addPresent(family.findNiece(NIECE_NINA), "Hair Pin");
        uncle2.addPresent(family.findNiece(NIECE_JOHAN), "Baseball Hat");

        uncle3.addPresent(family.findNiece(NIECE_DIETER), "Watercolor Paint");
        uncle3.addPresent(family.findNiece(NIECE_JOHAN), "Quantum Physics Book");

        // Uncle gives the same gift - Testing duplicate gifts
        uncle3.addPresent(family.findNiece(NIECE_NINA), "Quantum Physics Book");

        // Check that two uncles give the same gift to one niece - Testing duplicate gifts
        uncle2.addPresent(family.findNiece(NIECE_DIETER), "Watercolor Paint");

        // Display lists of nieces and uncles
        family.listOfNieces();
        family.listOfUncles();

        // Display lists of presents given by each uncle
        uncle1.listPresents();
        uncle2.listPresents();
        uncle3.listPresents();

        // Display lists of presents received by each niece
        family.findNiece(NIECE_NINA).listPresents();
        family.findNiece(NIECE_DIETER).listPresents();
        family.findNiece(NIECE_JOHAN).listPresents();
    }
}

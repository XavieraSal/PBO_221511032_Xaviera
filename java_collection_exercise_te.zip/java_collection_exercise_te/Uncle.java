package java_collection_exercise_te;

import java.util.*;

public class Uncle implements Comparable<Uncle> {
    private String name;
    private Map<Niece, String> presents = new HashMap<Niece, String>();

    // Setter for Uncle's name
    public void setName(String name) {
        this.name = name;
    }

    // Getter for Uncle's name
    public String getName() {
        return this.name;
    }

    // Adds a present for the niece, ensuring it's unique among uncles and nieces
    public boolean addPresent(Niece receiver, String gift) {
        if (!presents.containsValue(gift) && !receiver.getPresents().containsValue(gift) || gift == null) {
            // Add the present to both the uncle's and niece's present lists
            presents.put(receiver, gift);
            receiver.getPresents().put(this, gift);
            return true;
        }
        return false;
    }

    // Getter for Uncle's presents map
    public Map<Niece, String> getPresents() {
        return this.presents;
    }

    // Lists all presents given by the uncle, indicating if no present is chosen
    public void listPresents() {
        System.out.println("***********************************************");
        System.out.println("List of presents from " + this.name + ":");
        for (Map.Entry<Niece, String> entry : presents.entrySet()) {
            System.out.print("- ");
            System.out.print((entry.getValue() == null ? "No present has been chosen for " : entry.getValue() + " for "));
            System.out.println(entry.getKey().getName());
        }
    }

    // String representation of the Uncle object
    @Override
    public String toString() {
        return "\n" + "Name: " + name + "(Uncle)";
    }

    // Equals method to compare Uncle objects based on their names
    @Override
    public boolean equals(Object object) {
        if (object == this) return true;
        if (object == null) return false;
        if (getClass() != object.getClass()) return false;
        return name.equals(((Uncle) object).name);
    }

    // HashCode method to generate a hash based on the name
    @Override
    public int hashCode() {
        return name.hashCode();
    }

    // CompareTo method to enable sorting of Uncle objects based on names
    @Override
    public int compareTo(Uncle uncle) {
        return name.compareTo(uncle.name);
    }
}

package java_collection_exercise_te;

import java.util.*;

public class Niece implements Comparable<Niece> {
    private String name;
    private int birthDay;
    private int birthMonth;
    Map<Uncle, String> presents = new HashMap<Uncle, String>();

    // Setters for Niece attributes
    public void setName(String name) {
        this.name = name;
    }

    public void setBirthDay(int birthDay) {
        this.birthDay = birthDay;
    }

    public void setBirthMonth(int birthMonth) {
        this.birthMonth = birthMonth;
    }

    // Getters for Niece attributes
    public String getName() {
        return this.name;
    }

    public int getBirthDay() {
        return this.birthDay;
    }

    public int getBirthMonth() {
        return this.birthMonth;
    }

    // Getter for presents map
    public Map<Uncle, String> getPresents() {
        return this.presents;
    }

    // Clears all presents for the niece and returns the total number removed
    public int clearPresents() {
        int totalPresent = presents.size();
        presents.clear();
        return totalPresent;
    }

    // Lists all presents for the niece, indicating if a present is not given
    public void listPresents() {
        System.out.println("***********************************************");
        System.out.println("List of presents for " + this.name + ":");
        for (Map.Entry<Uncle, String> entry : presents.entrySet()) {
            System.out.print("- ");
            System.out.print(entry.getKey().getName());
            System.out.println((entry.getValue() == null ? " hasn't given present" : " gives " + entry.getValue()));
        }
    }

    // String representation of the Niece object
    @Override
    public String toString() {
        return "\n" + "Name: " + name + "(Niece)" + " | Birth Day: " + birthDay + "-" + birthMonth;
    }

    // Equals method to compare Niece objects based on their names
    @Override
    public boolean equals(Object object) {
        if (object == this) return true;
        if (object == null) return false;
        if (getClass() != object.getClass()) return false;
        return name.equals(((Niece) object).name);
    }

    // HashCode method to generate a hash based on the name
    @Override
    public int hashCode() {
        return name.hashCode();
    }

    // CompareTo method to enable sorting of Niece objects based on birth month and day
    @Override
    public int compareTo(Niece niece) {
        if (this.birthMonth > niece.birthMonth) return 1;
        if (this.birthMonth == niece.birthMonth) {
            return (this.birthDay > niece.birthDay ? 1 : -1);
        }
        return -1;
    }
}

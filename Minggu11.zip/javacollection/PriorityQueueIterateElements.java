package com.minggu11.javacollection;

/**
*<h1> iterate through all elements</h1> 
*Java program to iterate through all elements in the priority queue.
*@author https://www.w3resource.com/
*@lastUpdate 2023-04-30
*/

import java.util.PriorityQueue;

public class PriorityQueueIterateElements {
	  public static void main(String[] args) {
		    PriorityQueue<String> pq = new PriorityQueue<String>();  
		  pq.add("Red");
		  pq.add("Green");
		  pq.add("Orange");
		  pq.add("White");
		  pq.add("Black");
		  System.out.println("Elements of the Priority Queue: ");
		  // iterate the Priority Queue
		  for (String element : pq) {
		    System.out.println(element);
		    }
		 }
}

package com.minggu11.javacollection;

/**
*<h1> Create Priority Queue s</h1> 
*Java program to create a priority queue, add some colors (strings) and print out the elements of the priority queue.
*@author https://www.w3resource.com/
*@lastUpdate 2023-04-30
*/

import java.util.PriorityQueue;

public class PriorityQueueCreate {
	  public static void main(String[] args) {
		  PriorityQueue<String> queue=new PriorityQueue<String>();  
		  queue.add("Red");
		  queue.add("Green");
		  queue.add("Orange");
		  queue.add("White");
		  queue.add("Black");
		  System.out.println("Elements of the Priority Queue: ");
		  System.out.println(queue);
		 }
}

package com.minggu8.studikasus2;

//**************************************************
//Paint.java
//
//Represents a type of paint that has a fixed area
// coveres by a gallon. All measurements are in feet
//**************************************************

public class Paint {
	private double coverage; //number of square feet per gallon.
	
	//**************************************************
	// Constructor: Sets up the paint object.
	//**************************************************
	
	public Paint(double c) {
		coverage = c;
	}
	
	//**************************************************
	// Returns the amount of paint (number of gallons)
	// needed to paint the shape given as the parameter.
	//**************************************************
		
	public double amount(Shape s) {
		System.out.println("Computing amount for " + s);
		//the amount of paint needed is the area of the shape divided by the coverage for the paint.
		return s.area() / coverage;
	}
}

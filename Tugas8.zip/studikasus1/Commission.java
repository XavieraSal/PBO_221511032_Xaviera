package com.minggu8.studikasus1;

//********************************************************************
//Commission.java Author: Xaviera Sadiya S
//
//Represents a staff member that works as a commission that paid by an hour.
//********************************************************************


public class Commission extends Hourly {
    private double totalSales;
    private double commissionRate;

    public Commission(String eName, String eAddress, String ePhone, String socSecNumber, double rate, double commissionRate) {
        super(eName, eAddress, ePhone, socSecNumber, rate);
        this.commissionRate = commissionRate;
    }

    public void addSales(double totalSales) {
        this.totalSales += totalSales;
    }

    @Override
    public double pay() {
        double hourlyPayment = super.pay();
        double commissionPayment = totalSales * commissionRate;
        totalSales = 0; // Reset total sales
        return hourlyPayment + commissionPayment;
    }

    @Override
    public String toString() {
        String hourlyInfo = super.toString();
        return hourlyInfo + "\nTotal Sales: $" + totalSales;
    }
}

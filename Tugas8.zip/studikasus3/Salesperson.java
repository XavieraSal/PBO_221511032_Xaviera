package com.minggu8.studikasus3;

//********************************************************************
// Salesperson.java
// Represents a sales person who has a first name, lasy
// name, and total number of sales.
//********************************************************************
	
public class Salesperson implements Comparable{
	
	private String firstName, lastName;
	private int totalSales;
	
	//********************************************************************
	// Constructor : Sets up the sales person object with
	//				the given data.
	//********************************************************************
	
	public Salesperson(String first, String last, int sales)
	{
		firstName = first;
		lastName = last;
		totalSales = sales;
	}
	
	//********************************************************************
	// Returns the sales person as a String/
	//********************************************************************
	@Override
	public String toString()
	{
		return lastName + ", " + firstName + ":  \t" + totalSales;
	}
	
	
	//********************************************************************
	// Returns true if the sales people have the same name
	//********************************************************************
	@Override	
	public boolean equals (Object other)
	{
		return (lastName.equals(((Salesperson)other).getLastName()) &&
				 firstName.equals(((Salesperson)other).getFirstName()));
	}
	
	//********************************************************************
	// Order is based on total sales with the name
	// (last, then first) breaking a tie
	//********************************************************************
	
	@Override
	public int compareTo(Object other) {
	    int result = Integer.compare(this.totalSales, ((Salesperson)other).getTotalSales());
	    if (result == 0) {
	        result = this.lastName.compareTo(((Salesperson)other).getLastName());
	        if (result == 0) {
	            result = this.firstName.compareTo(((Salesperson)other).getFirstName());
	        }
	    }
	    return result;
	}

	

	//********************************************************************
	// First name acessor
	//********************************************************************
	public String getFirstName() {
		return firstName;
	}
	//********************************************************************
	// Last name acessor
	// ********************************************************************
	public String getLastName() {
		return lastName;
	}
	//********************************************************************
	// First name acessor
	// ********************************************************************
	public int getTotalSales() {
		return totalSales;
	}

}


package com.minggu6.relationship;

/**
 * The ManagerTest class is a test program to demonstrate polymorphism with Employee and Manager objects.
 */
public class ManagerTest {
    public static void main(String[] args) {
        Employee[] staff = new Employee[3];

        // Create Employee and Manager instances and add them to the staff array
        staff[0] = new Employee("Antonio Rossi", 2000000, 1, 10, 1989);
        staff[1] = new Manager("Maria Bianchi", 2500000, 1, 12, 1991);
        staff[2] = new Employee("Isabel Vidal", 3000000, 1, 11, 1993);

        Sortable.shell_sort(staff);
        
        int i;

        // Raise the salary of all staff members by 5%
        for (i = 0; i < 3; i++) {
            staff[i].raiseSalary(5);
        }

        // Print information about each staff member
        for (i = 0; i < 3; i++) {
            staff[i].print();
        }
    }
}

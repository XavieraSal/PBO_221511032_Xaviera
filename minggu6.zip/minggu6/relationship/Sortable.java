package com.minggu6.relationship;

/**
 * The Sortable abstract class represents objects that can be sorted using the shell sort algorithm.
 */
public abstract class Sortable {
    /**
     * Compare this object with another object of the same type.
     *
     * @param b The object to compare with.
     * @return An integer indicating the comparison result.
     */
    public abstract int compare(Sortable b);

    /**
     * Sort an array of Sortable objects using the shell sort algorithm.
     *
     * @param a The array of Sortable objects to be sorted.
     */
    public static void shell_sort(Sortable[] a) {
        int n = a.length;
        for (int interval = n / 2; interval > 0; interval /= 2) {
            for (int i = interval; i < n; i += 1) {
                Sortable temp = a[i];
                int j;

                for (j = i; j >= interval; j -= interval) {
                    a[j] = a[j - interval];
                }

                a[j] = temp;
            }
        }
    }
}

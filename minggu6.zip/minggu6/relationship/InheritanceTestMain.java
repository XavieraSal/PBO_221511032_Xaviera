package com.minggu6.relationship;

/**
 * A test class to demonstrate inheritance and polymorphism using Shape, Circle_2, Rectangle, and Square classes.
 */
public class InheritanceTestMain {
    public static void main(String[] args) {
        // Create a Shape instance with red color and not filled
        Shape shape = new Shape("red", false);
        System.out.println(shape); // Print the description of the shape
        System.out.println();

        // Create a Circle_2 instance with a radius of 5.0, blue color, and filled
        Circle_2 circle = new Circle_2(5.0, "blue", true);
        System.out.println(circle); // Print the description of the circle
        System.out.println("Area: " + circle.getArea()); // Calculate and print the area of the circle
        System.out.println("Perimeter: " + circle.getPerimeter()); // Calculate and print the perimeter of the circle
        System.out.println();

        // Create a Rectangle instance with a width of 4.0, length of 6.0, yellow color, and filled
        Rectangle rectangle = new Rectangle(4.0, 6.0, "yellow", true);
        System.out.println(rectangle); // Print the description of the rectangle
        System.out.println("Area: " + rectangle.getArea()); // Calculate and print the area of the rectangle
        System.out.println("Perimeter: " + rectangle.getPerimeter()); // Calculate and print the perimeter of the rectangle
        System.out.println();

        // Create a Square instance with a side length of 3.0, green color, and not filled
        Square square = new Square(3.0, "green", false);
        System.out.println(square); // Print the description of the square
        System.out.println("Area: " + square.getArea()); // Calculate and print the area of the square
        System.out.println("Perimeter: " + square.getPerimeter()); // Calculate and print the perimeter of the square
    }
}

package com.minggu6.relationship;

/**
 * The Circle class models a circle with a radius and color.
 */
public class Circle {
    // Private instance variables, not accessible from outside this class
    private double radius;
    private String color;

    // Constructors (overloaded)

    /**
     * Constructs a Circle instance with the default value for radius and color.
     */
    public Circle() { // 1st (default) constructor
        radius = 1.0;
        color = "red";
    }

    /**
     * Constructs a Circle instance with the given radius and default color.
     *
     * @param r The radius of the circle.
     */
    public Circle(double r) { // 2nd constructor
        radius = r;
        color = "red";
    }

    /**
     * Constructs a Circle instance with the given radius and color.
     *
     * @param r The radius of the circle.
     * @param c The color of the circle.
     */
    public Circle(double r, String c) {
        radius = r;
        color = c;
    }

    // Getter and setter for color

    /**
     * Get the color of the circle.
     *
     * @return The color of the circle.
     */
    public String getColor() {
        return color;
    }

    /**
     * Set the color of the circle.
     *
     * @param color The new color to set.
     */
    public void setColor(String color) {
        this.color = color;
    }

    /**
     * Returns the radius of the circle.
     *
     * @return The radius of the circle.
     */
    public double getRadius() {
        return radius;
    }

    /**
     * Returns the area of this Circle instance.
     *
     * @return The area of the circle.
     */
    public double getArea() {
        return radius * radius * Math.PI;
    }

    /**
     * Return a self-descriptive string of this instance in the form of Circle[radius=?, color=?].
     *
     * @return A string representation of the circle.
     */
    @Override
    public String toString() {
        return "Circle[radius=" + radius + ", color=" + color + "]";
    }
}

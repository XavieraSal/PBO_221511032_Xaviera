package com.minggu6.relationship;

/**
 * The Square class represents a square with equal side lengths and inherits properties from Rectangle.
 */
public class Square extends Rectangle {
    // Constructors

    /**
     * Constructs a Square instance with default side length, color, and filled properties and inherits from Rectangle.
     */
    public Square() {
        super();
    }

    /**
     * Constructs a Square instance with a given side length, and inherits color and filled properties from Rectangle.
     *
     * @param side The side length of the square.
     */
    public Square(double side) {
        super(side, side);
    }

    /**
     * Constructs a Square instance with a given side length, color, and filled properties.
     *
     * @param side   The side length of the square.
     * @param color  The color of the square.
     * @param filled Whether the square is filled (true) or not filled (false).
     */
    public Square(double side, String color, boolean filled) {
        super(side, side, color, filled);
    }

    /**
     * Get the side length of the square.
     *
     * @return The side length of the square.
     */
    public double getSide() {
        return super.getWidth(); // Can retrieve either width or length since they are the same in a square
    }

    /**
     * Set the side length of the square.
     *
     * @param side The new side length to set.
     */
    public void setSide(double side) {
        super.setLength(side);
        super.setWidth(side);
    }

    /**
     * Override the setWidth method to change both width and length, maintaining square geometry.
     *
     * @param width The new width to set.
     */
    @Override
    public void setWidth(double width) {
        setSide(width);
    }

    /**
     * Override the setLength method to change both length and width, maintaining square geometry.
     *
     * @param length The new length to set.
     */
    @Override
    public void setLength(double length) {
        setSide(length);
    }

    /**
     * Override the toString method to provide a string representation of the square.
     *
     * @return A string describing the square's side length and its relationship to the superclass Rectangle.
     */
    @Override
    public String toString() {
        return "A Square with side=" + getSide() + ", which is a subclass of " + super.toString();
    }
}

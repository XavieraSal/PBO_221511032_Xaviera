package com.minggu6.relationship;

/**
 * A class representing a geometric shape with color and fill properties.
 */
public class Shape {
    /* Instance Variables */
    private String color;
    private boolean filled;

    /**
     * Default constructor that initializes color to "green" and filled to true.
     */
    public Shape() {
        color = "green";
        filled = true;
    }

    /**
     * Constructor that initializes color and filled properties.
     *
     * @param color  The color of the shape.
     * @param filled Whether the shape is filled (true) or not filled (false).
     */
    public Shape(String color, boolean filled) {
        this.color = color;
        this.filled = filled;
    }

    /**
     * Get the color of the shape.
     *
     * @return The color of the shape.
     */
    public String getColor() {
        return color;
    }

    /**
     * Check if the shape is filled.
     *
     * @return True if the shape is filled, false otherwise.
     */
    public boolean isFilled() {
        return filled;
    }

    /**
     * Set the filled property of the shape.
     *
     * @param filled Whether the shape should be filled (true) or not filled (false).
     */
    public void setFilled(boolean filled) {
        this.filled = filled;
    }

    /**
     * Get a string representation of the shape.
     *
     * @return A string describing the shape's color and fill properties.
     */
    @Override
    public String toString() {
        return "A Shape with color of " + getColor() + " and filled " + isFilled();
    }
}

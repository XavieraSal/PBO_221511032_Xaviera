package com.minggu6.relationship;

/**
 * The Rectangle class represents a rectangle with width, length, and inherits properties from Shape.
 */
public class Rectangle extends Shape {
    private double width;
    private double length;

    // Constructors

    /**
     * Constructs a Rectangle instance with default width and length of 1.0 and inherits color and filled properties from Shape.
     */
    public Rectangle() {
        width = 1.0;
        length = 1.0;
    }

    /**
     * Constructs a Rectangle instance with the given width and length and inherits color and filled properties from Shape.
     *
     * @param width  The width of the rectangle.
     * @param length The length of the rectangle.
     */
    public Rectangle(double width, double length) {
        this.width = width;
        this.length = length;
    }

    /**
     * Constructs a Rectangle instance with the given width, length, color, and filled properties.
     *
     * @param width  The width of the rectangle.
     * @param length The length of the rectangle.
     * @param color  The color of the rectangle.
     * @param filled Whether the rectangle is filled (true) or not filled (false).
     */
    public Rectangle(double width, double length, String color, boolean filled) {
        super(color, filled); // Call the superclass constructor Shape(color, filled)
        this.width = width;
        this.length = length;
    }

    /**
     * Get the length of the rectangle.
     *
     * @return The length of the rectangle.
     */
    public double getLength() {
        return length;
    }

    /**
     * Get the width of the rectangle.
     *
     * @return The width of the rectangle.
     */
    public double getWidth() {
        return width;
    }

    /**
     * Set the length of the rectangle.
     *
     * @param length The new length to set.
     */
    public void setLength(double length) {
        this.length = length;
    }

    /**
     * Set the width of the rectangle.
     *
     * @param width The new width to set.
     */
    public void setWidth(double width) {
        this.width = width;
    }

    /**
     * Calculate and return the area of the rectangle.
     *
     * @return The area of the rectangle.
     */
    public double getArea() {
        return width * length;
    }

    /**
     * Calculate and return the perimeter of the rectangle.
     *
     * @return The perimeter of the rectangle.
     */
    public double getPerimeter() {
        return 2 * (width + length);
    }

    /**
     * Override the toString method to provide a string representation of the rectangle.
     *
     * @return A string describing the rectangle's width, length, and its relationship to the superclass Shape.
     */
    @Override
    public String toString() {
        return "A Rectangle with width=" + width + " and length=" + length + ", which is a subclass of " + super.toString();
    }
}

package com.minggu6.relationship;

import java.util.Calendar;
import java.util.GregorianCalendar;

/**
 * The Manager class is a subclass of Employee and represents a manager with additional properties.
 */
public class Manager extends Employee {
    private String secretaryName; // Private variable to store the secretary's name

    /**
     * Constructs a Manager instance with the given name, salary, hire date, and an empty secretary name.
     *
     * @param n   The name of the manager.
     * @param s   The salary of the manager.
     * @param d   The day of the hire date.
     * @param m   The month of the hire date.
     * @param y   The year of the hire date.
     */
    public Manager(String n, double s, int d, int m, int y) {
        super(n, s, d, m, y); // Call the superclass constructor of Employee
        secretaryName = "";
    }

    /**
    * Override the raiseSalary method to add a 1/2% bonus for every year of service.
    *
    * @param byPercent The percentage by which to raise the salary.
    */
   @Override
   public void raiseSalary(double byPercent) {
       // Calculate the bonus based on years of service
       GregorianCalendar todaysDate = new GregorianCalendar();
       int currentYear = todaysDate.get(Calendar.YEAR);
       double bonus = 0.5 * (currentYear - hireYear());

       // Call the superclass method to raise the salary with the bonus
       super.raiseSalary(byPercent + bonus);
   }

   /**
    * Get the secretary's name.
    *
    * @return The secretary's name.
    */
   public String getSecretaryName() {
       return secretaryName;
   }
}

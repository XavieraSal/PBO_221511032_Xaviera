package com.minggu6.relationship;

/**
 * The Circle_2 class represents a circle with a radius and inherits properties from Shape.
 */
public class Circle_2 extends Shape {
    private double radius; // Private variable for the radius of the circle

    // Constructors

    /**
     * Constructs a Circle_2 instance with a default radius of 1.0 and inherits color and filled properties from Shape.
     */
    public Circle_2() {
        radius = 1.0;
    }

    /**
     * Constructs a Circle_2 instance with the given radius and inherits color and filled properties from Shape.
     *
     * @param radius The radius of the circle.
     */
    public Circle_2(double radius) {
        this.radius = radius;
    }

    /**
     * Constructs a Circle_2 instance with the given radius, color, and filled properties.
     *
     * @param radius The radius of the circle.
     * @param color  The color of the circle.
     * @param filled Whether the circle is filled (true) or not filled (false).
     */
    public Circle_2(double radius, String color, boolean filled) {
        super(color, filled); // Call the superclass constructor Shape(color, filled)
        this.radius = radius;
    }

    // Getter and setter for radius

    /**
     * Get the radius of the circle.
     *
     * @return The radius of the circle.
     */
    public double getRadius() {
        return radius;
    }

    /**
     * Set the radius of the circle.
     *
     * @param radius The new radius to set.
     */
    public void setRadius(double radius) {
        this.radius = radius;
    }

    /**
     * Calculate and return the area of the circle.
     *
     * @return The area of the circle.
     */
    public double getArea() {
        return radius * radius * Math.PI;
    }

    /**
     * Calculate and return the perimeter of the circle.
     *
     * @return The perimeter of the circle.
     */
    public double getPerimeter() {
        return 2 * Math.PI * radius;
    }

    /**
     * Override the toString method to provide a string representation of the circle.
     *
     * @return A string describing the circle's radius and its relationship to the superclass Shape.
     */
    @Override
    public String toString() {
        return "A Circle with radius=" + radius + ", which is a subclass of " + super.toString();
    }
}

package com.minggu6.relationship;

/**
 * The Cylinder class models a cylinder with a height and inherits properties from Circle.
 */
public class Cylinder extends Circle {
    private double height; // Private variable for the height of the cylinder

    // Constructors

    /**
     * Constructs a Cylinder instance with default color, radius, and height.
     */
    public Cylinder() {
        super(); // Call the superclass no-arg constructor Circle()
        height = 1.0;
    }

    /**
     * Constructs a Cylinder instance with default radius and color, but a given height.
     *
     * @param height The height of the cylinder.
     */
    public Cylinder(double height) {
        super(); // Call the superclass no-arg constructor Circle()
        this.height = height;
    }

    /**
     * Constructs a Cylinder instance with a given radius, height, and default color.
     *
     * @param radius The radius of the base circle of the cylinder.
     * @param height The height of the cylinder.
     */
    public Cylinder(double radius, double height) {
        super(radius); // Call the superclass constructor Circle(radius)
        this.height = height;
    }

    /**
     * Get the height of the cylinder.
     *
     * @return The height of the cylinder.
     */
    public double getHeight() {
        return height;
    }

    /**
     * Compute the volume of the cylinder using the superclass method getArea() to get the base area.
     *
     * @return The volume of the cylinder.
     */
    public double getVolume() {
        return super.getArea() * height;
    }

    /**
     * Override the getArea method to compute the surface area of the cylinder.
     *
     * @return The surface area of the cylinder.
     */
    @Override
    public double getArea() {
        return 2 * Math.PI * super.getRadius() * height + 2 * super.getArea();
    }

    /**
     * Return a self-descriptive string of this instance in the form of "Cylinder: subclass of Circle[radius=?, color=?] height=?"
     *
     * @return A string representation of the cylinder.
     */
    @Override
    public String toString() {
        return "Cylinder: subclass of " + super.toString() // Use Circle's toString()
                + " height=" + height;
    }
}

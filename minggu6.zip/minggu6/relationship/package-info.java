package com.minggu6.relationship;

/*
*@author Xaviera Sadiya Salsabeel
*Program to give the implementation of Inheritance, Abstract Class and Interface
*@version 1.0
*@since 08-OCT-2023
*/

/**
 * Week 7 : Inheritance, Abstract Class and Interface
 * Exercise 1 : The Circle and Cylinder Classes
 * This exercise demonstrates concepts in inheritance and method overriding.
 *
 * [Task 1.1] Modify class Circle:
 * - Added variable color (String).
 * - Added Constructor Circle(radius: double, color: String).
 * - Added Getter and Setter for color.
 *
 * [Task 1.2] Overriding the getArea() method:
 * - Overridden the getArea() method in the subclass Cylinder to compute the surface area of the cylinder.
 * - Updated the getVolume() method accordingly.
 *
 * [Task 1.3] Provided a toString() method for the Cylinder class.
 *
 * [Task 2.1] Superclass Shape and its Subclasses Circle, Rectangle, and Square:
 * - Created superclass Shape with color and filled instance variables, constructors, getters, setters, and toString() method.
 * - Created subclasses Circle and Rectangle with constructors, getters, setters, getArea(), getPerimeter(), and overridden toString() method.
 * - Created a subclass Square, modeling it as a subclass of Rectangle, with appropriate constructors, overridden toString() method, and overridden setLength() and setWidth() methods.
 * /**
 * This package contains classes related to Task 3.1 - Extending the Sortable abstract class.
 * 
 * [Task 3.1] Extending the Sortable abstract class:
 * - The abstract class Sortable defines a compare method for sorting objects.
 * - The Employee class extends Sortable and implements the compare method to compare employees based on salary.
 * - The EmployeeTest class tests the sorting functionality by creating an array of employees and sorting them using shell sort.
 * 
 * [Case 1]:
 * - In Case 1, the Sortable abstract class defines a compare method and a shell_sort static method.
 * - The Employee class extends Sortable and provides an implementation for the compare method to compare employees based on their salaries.
 * - The EmployeeTest class demonstrates the sorting functionality by sorting an array of employees using the shell_sort method.
 * 
 * [Case 2]:
 * - Case 2 explores the possibility of ordering Manager objects in a similar way to employees.
 * - It discusses the challenges and potential solutions for extending the sorting functionality to Manager objects.
 * 
 * @see com.minggu6.relationship.Sortable
 * @see com.minggu6.relationship.Employee
 * @see com.minggu6.relationship.EmployeeTest
 */
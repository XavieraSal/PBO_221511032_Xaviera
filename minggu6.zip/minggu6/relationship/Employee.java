package com.minggu6.relationship;

/**
 * The Employee class represents an employee with name, salary, and hire date.
 * It implements the Sortable interface for custom sorting based on salary.
 */
public class Employee extends Sortable {
    private String name;
    private double salary;
    private int hireday;
    private int hiremonth;
    private int hireyear;

    /**
     * Constructs an Employee instance with the given name, salary, and hire date.
     *
     * @param n     The name of the employee.
     * @param s     The salary of the employee.
     * @param day   The hire day.
     * @param month The hire month.
     * @param year  The hire year.
     */
    public Employee(String n, double s, int day, int month, int year) {
        name = n;
        salary = s;
        hireday = day;
        hiremonth = month;
        hireyear = year;
    }

    /**
     * Print the details of the employee.
     */
    public void print() {
        System.out.println(name + " " + salary + " " + hireYear());
    }

    /**
     * Raise the salary of the employee by the given percentage.
     *
     * @param byPercent The percentage by which to raise the salary.
     */
    public void raiseSalary(double byPercent) {
        salary *= 1 + byPercent / 100;
    }

    /**
     * Get the hire year of the employee.
     *
     * @return The hire year.
     */
    public int hireYear() {
        return hireyear;
    }

    /**
     * Compare this employee with another Sortable object based on salary.
     *
     * @param b The object to compare with.
     * @return An integer indicating the comparison result.
     */
    @Override
    public int compare(Sortable b) {
        Employee eb = (Employee) b;
        if (salary < eb.salary) return -1;
        if (salary > eb.salary) return 1;
        return 0;
    }
    
 // Metode untuk menaikkan gaji karyawan berdasarkan persentase tertentu
    
}

package com.minggu9;

import java.util.Scanner;

/**
*@author Xaviera
* This class provides a program for computing factorials of user-entered integers.
*@version 1.0
*@since 2023-10-26
*/
public class Factorials {

    /**
     * The main entry point of the program.
     *
     * @param args Command-line arguments (not used in this program).
     */
    public static void main(String[] args) {
        String keepGoing = "y";
        Scanner scan = new Scanner(System.in);

        while (keepGoing.equals("y") || keepGoing.equals("Y")) {
            System.out.print("Enter an integer: ");
            int val = scan.nextInt();
            try {
                System.out.println("Factorial(" + val + ") = " + MathUtils.factorial(val));
            } catch (IllegalArgumentException kesalahan) {
                System.out.println(kesalahan.getMessage());
            }
            System.out.print("Another Factorial? (y/n) ");
            keepGoing = scan.next();
        scan.close();
        }
    }
}

package com.minggu9;

/**
* 
*@author Xaviera
*A program that reads a line of text and calculates the sum of integers in that line.
*@version 1.0
*@since 2023-10-26
*
*/

import java.util.Scanner;

public class ParseInts {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        System.out.println("Enter a line of text");
        String inputLine = scan.nextLine();

        int sum = sumIntegersInString(inputLine);
        
        scan.close();
        
        System.out.println("The sum of the integers on this line is " + sum);
    }

    private static int sumIntegersInString(String input) {
        int sum = 0;
        Scanner scanner = new Scanner(input);

        while (scanner.hasNext()) {
            if (scanner.hasNextInt()) {
                sum += scanner.nextInt();
            } else {
                String invalidToken = scanner.next();
                System.out.println("Error: Invalid integer - " + invalidToken);
            }
        }

        scanner.close();
        return sum;
    }
}

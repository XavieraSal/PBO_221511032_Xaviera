package com.minggu9;

/**
*@author Xaviera
*This class provides utility methods for mathematical operations.
*@version 1.0
*@since 2023-10-26
*/

public class MathUtils {

    /**
     * Calculates the factorial of a non-negative integer.
     *
     * @param n The non-negative integer for which to calculate the factorial.
     * @return The factorial of the input integer.
     * @throws IllegalArgumentException if the input integer is negative or greater than 16.
     */
    public static int factorial(int n) {
        if (n < 0) {
            throw new IllegalArgumentException("Negative integer is not allowed.");
        } else if (n > 16) {
            throw new IllegalArgumentException("Integer above 16 is not factorial.");
        }
        int fac = 1;
        for (int i = n; i > 0; i--) {
            fac *= i;
        }
        return fac;
    }
}
